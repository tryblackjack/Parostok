import json
import tempfile
import unittest
from datetime import date
from pathlib import Path
from types import SimpleNamespace

from grantwriter.checks import FAIL, PASS, UNKNOWN, budget_summary, check_budget, check_eligibility
from grantwriter import sources
from grantwriter.drafters import (AnthropicBackend, ModelDrafter, OfflineDrafter,
                                  OpenAICompatibleBackend)
from grantwriter.models import InputError, load_call, load_profile, load_project
from grantwriter.pipeline import BLOCKED, INVALID, VALID_OPEN, run, sha256_file
from grantwriter.validate import segments, strip_markers, validate_section

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / "examples/profiles/1ua_age.yaml"
CALL = ROOT / "examples/calls/example_deeptech_call.yaml"
PROJECT = ROOT / "examples/projects/1ua_age_pcb_closure.yaml"


class Fixture(unittest.TestCase):
    def setUp(self):
        self.profile = load_profile(PROFILE)
        self.call = load_call(CALL)
        self.project = load_project(PROJECT)
        self.budget = budget_summary(self.project)
        self.section = next(s for s in self.call.sections if s.id == "state")

    def check(self, text, section=None):
        return [v.code for v in validate_section(section or self.section, text, self.profile,
                                                 self.project, self.budget)]


class ValidatorTest(Fixture):
    def test_clean_cited_sentence_passes(self):
        self.assertEqual(self.check("Missions run through the canonical runtime [F:F-CONDUCT]."), [])

    def test_uncited_sentence_rejected(self):
        self.assertIn("UNCITED_SENTENCE", self.check("Our team is excellent."))

    def test_unknown_fact_rejected(self):
        self.assertIn("UNKNOWN_FACT", self.check("We won an award [F:F-AWARD]."))

    def test_invented_number_rejected(self):
        codes = self.check("We passed 19 of 19 gates [F:F-PCB-BENCH].")
        self.assertEqual(codes, ["NUMBER_NOT_IN_SOURCE"])

    def test_number_from_cited_fact_allowed(self):
        self.assertEqual(self.check("The benchmark passed 18 of 19 gates but is not closed [F:F-PCB-BENCH]."), [])

    def test_overclaim_on_non_proven_fact_rejected(self):
        self.assertIn("STATUS_OVERCLAIM", self.check("The PCB design path is fully validated [F:F-PCB-2L]."))

    def test_qualified_claim_on_non_proven_fact_allowed(self):
        self.assertEqual(self.check("The PCB design path is partially validated [F:F-PCB-2L]."), [])
        self.assertEqual(self.check("The board is not yet validated physically [F:F-PHYSICAL]."), [])

    def test_overclaim_allowed_for_proven_fact(self):
        self.assertEqual(self.check("Deterministic dispatch is demonstrated [F:F-DETERMINISTIC]."), [])

    def test_forbidden_claim_rejected_unless_negated(self):
        self.assertIn("FORBIDDEN_CLAIM", self.check("The design is certified [F:F-CAD]."))
        self.assertEqual(self.check("The design is not certified yet [F:F-EXTERNAL-REVIEW]."), [])
        self.assertEqual(self.check(
            "Manufacturing release and certification have not been obtained [F:F-EXTERNAL-REVIEW]."), [])

    def test_budget_numbers_need_budget_marker(self):
        budget_section = next(s for s in self.call.sections if s.id == "budget")
        self.assertEqual(self.check("We request 40000 EUR [BUDGET].", budget_section), [])
        self.assertIn("NUMBER_NOT_IN_SOURCE", self.check("We request 40000 EUR [P:P-FAB].", budget_section))
        self.assertIn("NUMBER_NOT_IN_SOURCE", self.check("We request 50000 EUR [BUDGET].", budget_section))

    def test_equal_values_in_different_notation_match(self):
        budget_section = next(s for s in self.call.sections if s.id == "budget")
        self.assertEqual(self.check("Total cost is 45000.0 EUR [BUDGET].", budget_section), [])
        self.assertEqual(self.check("Total cost is 45,000 EUR [BUDGET].", budget_section), [])
        self.assertIn("NUMBER_NOT_IN_SOURCE",
                      self.check("Total cost is 45000.5 EUR [BUDGET].", budget_section))

    def test_unknown_marker_suggests_closest_id(self):
        v = validate_section(self.section, "Not closed [F:PCB-BENCH].", self.profile,
                             self.project, self.budget)
        self.assertEqual(v[0].code, "UNKNOWN_FACT")
        self.assertIn("did you mean [F:F-PCB-BENCH]?", v[0].detail)

    def test_product_name_digits_are_not_quantities(self):
        self.assertEqual(self.check("1UA-AGE missions run through the runtime [F:F-CONDUCT]."), [])
        self.assertIn("NUMBER_NOT_IN_SOURCE",
                      self.check("1UA-AGE runs 3 missions [F:F-CONDUCT]."))

    def test_target_capability_cannot_be_claimed_as_achieved(self):
        self.assertIn("STATUS_OVERCLAIM", self.check(
            "JARVIS has fully achieved the path to production preparation [F:F-TARGET]."))

    def test_word_limit(self):
        long = " ".join(["word"] * 300) + " [F:F-CAD]."
        self.assertIn("OVER_WORD_LIMIT", self.check(long))

    def test_marker_after_full_stop_attaches_to_sentence(self):
        self.assertEqual(segments("Runs missions. [F:F-CONDUCT]"), ["Runs missions. [F:F-CONDUCT]"])
        self.assertEqual(self.check("Runs missions. [F:F-CONDUCT]"), [])

    def test_strip_markers(self):
        self.assertEqual(strip_markers("Runs missions [F:F-CONDUCT].\n- a: 1 [BUDGET]"),
                         "Runs missions.\n- a: 1")


class GateTest(Fixture):
    def test_unset_organization_fields_are_unknown_not_guessed(self):
        results = check_eligibility(self.profile, self.call)
        self.assertTrue(results)
        self.assertTrue(all(r.result == UNKNOWN for r in results))

    def test_eligibility_pass_and_fail(self):
        self.profile.organization.update(org_type="startup", employees=80, trl=4)
        by_key = {r.id: r.result for r in check_eligibility(self.profile, self.call)}
        self.assertEqual(by_key, {"org_type": PASS, "employees": FAIL, "trl": PASS})

    def test_budget_rollup_and_rules(self):
        self.assertEqual(self.budget["total_cost"], 45000)
        self.assertEqual(self.budget["requested"], 40000)
        self.assertEqual(self.budget["by_category"]["subcontracting"], 13000)
        self.assertTrue(all(c.result == PASS for c in check_budget(self.project, self.call, self.budget)))

    def test_budget_cap_violation(self):
        rules = dict(self.call.budget_rules, max_request=30000)
        call = self.call.__class__(**{**self.call.__dict__, "budget_rules": rules})
        results = {c.id: c.result for c in check_budget(self.project, call, self.budget)}
        self.assertEqual(results["max_request"], FAIL)

    def test_real_call_requires_source_url(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "call.yaml"
            p.write_text(CALL.read_text().replace("synthetic: true", "synthetic: false"))
            with self.assertRaises(InputError):
                load_call(p)


class PipelineTest(unittest.TestCase):
    def test_offline_run_produces_verifiable_package(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d)
            report = run(PROFILE, CALL, PROJECT, out, OfflineDrafter())
            self.assertEqual(report["status"], VALID_OPEN)
            self.assertTrue(all(s["final_valid"] for s in report["sections"]))
            manifest = json.loads((out / "manifest.json").read_text())
            for name, digest in manifest["outputs"].items():
                self.assertEqual(sha256_file(out / name), digest)
            self.assertEqual(manifest["inputs"]["profile"]["sha256"], sha256_file(PROFILE))
            for line in (out / "SHA256SUMS").read_text().splitlines():
                digest, name = line.split("  ")
                self.assertEqual(sha256_file(out / name), digest)
            self.assertNotIn("[F:", (out / "application.md").read_text())

    def test_failed_gate_blocks_drafting(self):
        with tempfile.TemporaryDirectory() as d:
            project = Path(d) / "project.yaml"
            project.write_text(PROJECT.read_text().replace("amount: 28000", "amount: 98000"))
            report = run(PROFILE, CALL, project, Path(d) / "out", OfflineDrafter())
            self.assertEqual(report["status"], BLOCKED)
            self.assertEqual(report["sections"], [])
            self.assertFalse((Path(d) / "out" / "application.md").exists())


class FakeAnthropicClient:
    """Stands in for anthropic.Anthropic(); returns scripted section texts."""

    def __init__(self, texts):
        self.texts = list(texts)
        self.requests = []
        self.beta = SimpleNamespace(messages=SimpleNamespace(create=self._create))

    def _create(self, **kwargs):
        self.requests.append(kwargs)
        return SimpleNamespace(content=[SimpleNamespace(type="text", text=self.texts.pop(0))],
                               stop_reason="end_turn", model=kwargs["model"])


class FakeOpenAITransport:
    """Stands in for HTTP POST to an OpenAI-compatible /chat/completions."""

    def __init__(self, texts, finish="stop"):
        self.texts = list(texts)
        self.finish = finish
        self.requests = []

    def __call__(self, url, payload):
        self.requests.append((url, payload))
        return {"model": payload["model"],
                "choices": [{"message": {"content": self.texts.pop(0)},
                             "finish_reason": self.finish}]}


BAD = "The PCB benchmark fully passed 19 of 19 gates [F:F-PCB-BENCH]."
GOOD = "The PCB benchmark passed 18 of 19 gates and is not closed yet [F:F-PCB-BENCH]."


class ModelDrafterTest(Fixture):
    def _draft(self, backend, max_repairs=2):
        validate = lambda t: validate_section(self.section, t, self.profile, self.project, self.budget)
        return ModelDrafter(backend, max_repairs=max_repairs).draft(
            self.section, self.profile, self.project, self.call, self.budget, validate)

    def _assert_repaired(self, result):
        self.assertEqual(len(result.attempts), 2)
        self.assertEqual({v.code for v in result.attempts[0].violations},
                         {"NUMBER_NOT_IN_SOURCE", "STATUS_OVERCLAIM"})
        self.assertEqual(result.final.violations, [])

    def test_local_openai_compatible_repair_loop(self):
        transport = FakeOpenAITransport([BAD, GOOD])
        backend = OpenAICompatibleBackend("gemma-local", transport=transport)
        result = self._draft(backend)
        self._assert_repaired(result)
        url, payload = transport.requests[1]
        self.assertEqual(url, "http://localhost:11434/v1/chat/completions")
        self.assertEqual([m["role"] for m in payload["messages"]],
                         ["system", "user", "assistant", "user"])
        self.assertIn("NUMBER_NOT_IN_SOURCE", payload["messages"][3]["content"])
        self.assertIn("The only valid markers are: [F:F-EVIDENCE-CHAIN], [F:F-PCB-2L]", payload["messages"][3]["content"])
        self.assertIn('"marker": "[F:F-PCB-BENCH]"', payload["messages"][1]["content"])
        self.assertEqual(result.backend, "model:openai-compatible")

    def test_anthropic_backend_same_loop(self):
        client = FakeAnthropicClient([BAD, GOOD])
        result = self._draft(AnthropicBackend(client=client))
        self._assert_repaired(result)
        self.assertEqual([m["role"] for m in client.requests[1]["messages"]],
                         ["user", "assistant", "user"])
        self.assertEqual(client.requests[0]["fallbacks"], "default")

    def test_repairs_are_bounded(self):
        backend = OpenAICompatibleBackend("m", transport=FakeOpenAITransport(["Uncited."] * 2))
        result = self._draft(backend, max_repairs=1)
        self.assertEqual(len(result.attempts), 2)
        self.assertTrue(result.final.violations)

    def test_truncation_is_a_violation(self):
        backend = OpenAICompatibleBackend("m", transport=FakeOpenAITransport([GOOD], "length"))
        result = self._draft(backend, max_repairs=0)
        self.assertEqual([v.code for v in result.final.violations], ["TRUNCATED"])

    def test_unreachable_server_is_typed_failure(self):
        def down(url, payload):
            raise ConnectionRefusedError("connection refused")
        result = self._draft(OpenAICompatibleBackend("m", transport=down))
        self.assertEqual([v.code for v in result.final.violations], ["MODEL_UNAVAILABLE"])

    def test_missing_api_key_env_is_typed_failure(self):
        backend = OpenAICompatibleBackend("m", base_url="http://127.0.0.1:9",
                                          api_key_env="GRANTWRITER_TEST_UNSET_KEY")
        result = self._draft(backend)
        self.assertEqual([v.code for v in result.final.violations], ["MODEL_UNAVAILABLE"])
        self.assertIn("GRANTWRITER_TEST_UNSET_KEY", result.final.violations[0].detail)

    def test_invalid_final_draft_makes_package_invalid(self):
        backend = OpenAICompatibleBackend("m", transport=FakeOpenAITransport(["Uncited."] * 100))
        with tempfile.TemporaryDirectory() as d:
            report = run(PROFILE, CALL, PROJECT, Path(d), ModelDrafter(backend, max_repairs=0))
        self.assertEqual(report["status"], INVALID)


class CallGateTest(unittest.TestCase):
    def _call(self, d, replace):
        p = Path(d) / "call.yaml"
        text = CALL.read_text()
        for a, b in replace:
            text = text.replace(a, b)
        p.write_text(text)
        return p

    def test_unverified_call_is_open_item(self):
        with tempfile.TemporaryDirectory() as d:
            call = self._call(d, [("synthetic: true", "synthetic: false\nverified: false\n"
                                   "aggregator_url: https://example.org/opp/x")])
            report = run(PROFILE, call, PROJECT, Path(d) / "out", OfflineDrafter())
        self.assertEqual(report["status"], VALID_OPEN)
        self.assertTrue(any(o.startswith("CALL_NOT_VERIFIED") for o in report["open_items"]))

    def test_passed_deadline_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            call = self._call(d, [("language: en", "language: en\ndeadline: 2026-01-01")])
            report = run(PROFILE, call, PROJECT, Path(d) / "out", OfflineDrafter(),
                         today=date(2026, 10, 10))
        self.assertEqual(report["status"], BLOCKED)
        self.assertIn("DEADLINE_PASSED: 2026-01-01", report["blockers"])


UPF_CALL = ROOT / "examples/calls/upf4_2026.yaml"
PAROSTOK = ROOT / "examples/profiles/parostok_kare.yaml"


class RealCallTest(unittest.TestCase):
    def test_upf4_exclusions_are_open_items_never_passed_silently(self):
        from grantwriter.pipeline import gates
        profile, call = load_profile(PAROSTOK), load_call(UPF_CALL)
        self.assertTrue(call.verified)
        _, _, _, open_items, blockers = gates(profile, call, None, date(2026, 10, 11))
        self.assertEqual(blockers, [])
        self.assertEqual(sum(o.startswith("EXCLUSION_CHECK_REQUIRED") for o in open_items),
                         len(call.exclusions))
        self.assertTrue(any("Netherlands-registered lead applicant" in o for o in open_items))

    def test_upf4_blocks_without_dutch_lead_and_after_deadline(self):
        from grantwriter.pipeline import gates
        profile, call = load_profile(PAROSTOK), load_call(UPF_CALL)
        profile.organization["upf_dutch_lead_partner"] = False
        _, _, _, _, blockers = gates(profile, call, None, date(2027, 4, 9))
        self.assertTrue(any(b.startswith("ELIGIBILITY_FAIL") and "Netherlands" in b for b in blockers))
        self.assertIn("DEADLINE_PASSED: 2027-04-08", blockers)

    def test_check_cli_exit_codes(self):
        from grantwriter.__main__ import main
        import contextlib, io
        with contextlib.redirect_stdout(io.StringIO()) as out:
            code = main(["check", "--profile", str(PAROSTOK), "--call", str(UPF_CALL)])
        self.assertEqual(code, 0)
        self.assertIn("CHECK: OPEN_ITEMS", out.getvalue())


RSS = b"""<?xml version="1.0"?><rss version="2.0"><channel><title>t</title>
<item><title>Grant for deeptech hardware</title><link>https://agg.example/opp/a</link>
<description>Engineering innovation grant</description><guid>A1</guid>
<pubDate>Fri, 09 Oct 2026 00:00:00 +0300</pubDate></item>
<item><title>Bakery support</title><link>https://agg.example/opp/b</link>
<description>For bakeries</description><guid>B2</guid><pubDate>x</pubDate></item>
</channel></rss>"""

PAGE = """<html><head>
<script type="application/ld+json">{"@type":"MonetaryGrant","amount":[{"@type":"MonetaryAmount",
"currency":"EUR","maxValue":40000,"validThrough":"2026-12-01"}],
"funder":[{"name":"Fund A"},{"name":"Fund B"}]}</script></head><body>
<div id="opt-target_audience" class="scroll-itm"><h2>Audience</h2><ul><li>SMEs</li>
<li>Consortium of 3 partners</li></ul></div>
<div id="opt-contacts_links"><h2>Links</h2><div><a href="https://official.example/call">Official</a>
<a href="https://agg.example/login">login</a></div></div>
</body></html>""".encode()


class SourcesTest(unittest.TestCase):
    def test_parse_rss_and_page(self):
        opps = sources.parse_rss(RSS, "agg")
        self.assertEqual([o.id for o in opps], ["A1", "B2"])
        o = sources.enrich_from_page(opps[0], PAGE, "agg.example")
        self.assertEqual((o.amount_max, o.currency, o.deadline), (40000, "EUR", "2026-12-01"))
        self.assertEqual(o.funder, "Fund A; Fund B")
        self.assertEqual(o.sections["Audience"], "SMEs\nConsortium of 3 partners")
        self.assertEqual(o.external_links, ["https://official.example/call"])

    def test_discover_isolates_page_failures(self):
        def fetch(url):
            if url.endswith("/b"):
                raise TimeoutError("timed out")
            return RSS if url.endswith("rss.xml") else PAGE
        sources.SOURCES["test"] = {"feed": "https://agg.example/rss.xml", "host": "agg.example",
                                   "usage_policy": "test"}
        try:
            opps = sources.discover("test", delay=0, fetch=fetch)
        finally:
            del sources.SOURCES["test"]
        self.assertEqual(opps[0].currency, "EUR")
        self.assertIn("_fetch_error", opps[1].sections)

    def test_screening_uses_title_and_summary_and_flags_from_page(self):
        opps = sources.parse_rss(RSS, "agg")
        sources.enrich_from_page(opps[0], PAGE, "agg.example")
        opps[0].sections["Footer"] = "bakery email"  # boilerplate must not drive topic match
        search = {"keywords": ["deep tech", "engineering", "bakery"], "min_score": 1,
                  "flags": {"consortium_required": ["consortium"]}}
        rows = {r.opportunity_id: r for r in sources.screen(opps, search, date(2026, 10, 10))}
        self.assertEqual(rows["A1"].status, "CANDIDATE")
        self.assertEqual(rows["A1"].matched, ["deep tech", "engineering"])
        self.assertIn("consortium_required", rows["A1"].flags)
        self.assertEqual(rows["B2"].matched, ["bakery"])
        strict = sources.screen(opps, dict(search, min_score=2), date(2026, 10, 10))
        self.assertEqual({r.opportunity_id: r.status for r in strict}["B2"], "EXCLUDED")
        expired = sources.screen(opps, search, date(2027, 1, 1))
        self.assertEqual({r.opportunity_id: r.status for r in expired}["A1"], "EXPIRED")

    def test_skeleton_is_unverified_and_loadable(self):
        import yaml
        o = sources.enrich_from_page(sources.parse_rss(RSS, "agg")[0], PAGE, "agg.example")
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "call.yaml"
            p.write_text(yaml.safe_dump(sources.call_skeleton(o), allow_unicode=True))
            call = load_call(p)
        self.assertFalse(call.verified)
        self.assertEqual(call.deadline, "2026-12-01")
        self.assertEqual(call.budget_rules, {"currency": "EUR", "max_request": 40000})


if __name__ == "__main__":
    unittest.main()
