# Receipt: local-model drafting runs, 2026-10-10

Attribution: developer-invoked execution. Claude Code (builder) launched the
runs at the owner's request. The model was `gemma4:e2b` served by Ollama 0.40.2
on CPU (4 cores, no GPU) inside the builder's container. No cloud model API was used.

Inputs: `examples/profiles/1ua_age.yaml`, `examples/calls/example_deeptech_call.yaml`
(synthetic call) and `examples/projects/1ua_age_pcb_closure.yaml` (placeholder budget).
Run with: `--backend openai-compatible --model gemma4:e2b`, `max_repairs=2`.

| Run | Code | Status | Valid sections | Model calls | Violations on first attempts | report.json sha256 (prefix) |
|---|---|---|---|---|---|---|
| 1 | 6975b0b | APPLICATION_DRAFT_INVALID | 0/6 | 18 | 51 | b499c404f8ffe1ff |
| 2 | 9859c21 | APPLICATION_DRAFT_INVALID | 4/6 | 11 | 6 | d0a27b9d41e9eed5 |
| 3 | 444e74c | APPLICATION_DRAFT_VALID_WITH_OPEN_ITEMS | 6/6 | 6 | 0 | d3f110af43d544a9 |

Run 1 used Ollama's default 4k context; runs 2 and 3 used `OLLAMA_CONTEXT_LENGTH=16384`.

## Failure → change chain

1. Run 1, `UNKNOWN_FACT` / `UNKNOWN_PLAN_ITEM`: the model wrote `[F:PCB-BENCH]` for
   `[F:F-PCB-BENCH]`. Change: facts and plan items are given to the model with their
   exact `marker`, and the validator suggests the closest id.
2. Run 1, `NUMBER_NOT_IN_SOURCE` on budget figures: `45000.0` was not equal to `45000`.
   Change: numbers are normalized to a canonical value (validator bug fix; the rule
   is unchanged).
3. Run 1, repair turns repeated identical violations: the feedback had no valid ids.
   Change: the repair prompt lists the only valid markers.
4. Run 1, `TRUNCATED`: the 4k context overflowed during repairs. Change: the server
   context was raised to 16k (deployment setting, documented in the README).
5. Run 2, `UNCITED_SENTENCE` (`[P:]`, `[Product Summary]`) and `NUMBER_NOT_IN_SOURCE`
   ('1' from "1UA-AGE"): the free-text product summary could not be cited. Change: the
   summary became citable facts (F-PRODUCT, F-TARGET NOT_PROVEN, F-ACCEPTANCE-RULE),
   and the product name is excluded from the number check.

No validator rule was relaxed to raise the pass rate. Changes 2 and 5b correct how
values and names are compared; the remaining changes concern how inputs are given
to the model.

## Human review of run 3 (not covered by the validator)

- Numbers, statuses and limitations are reported correctly: the PCB benchmark is shown
  as not closed at 18 of 19 gates, and there is no physical validation or certification.
- One semantic distortion: in "Risks", the model presents the safeguard "a critical
  unresolved contradiction blocks the release assessment" as a risk to be mitigated by
  replanning. The validator is lexical and cannot detect this. Human review stays mandatory.

## What this does and does not show

Shown: within this synthetic scope, a 2B-class local model plus the deterministic
validator produced a fully cited draft, and the failure records drove concrete changes.
Not shown: performance on a real call, other models, other languages (the run was in
English), reviewer acceptance or funding outcome. Run 3 is a single sample, so
reproducibility across seeds is untested.
