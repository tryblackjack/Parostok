"""Deterministic claim validator for drafted sections.

Contract for drafted text: every sentence (and every list item) carries at
least one marker:
  [F:ID]    - evidence fact from the product profile
  [P:ID]    - item of the project plan (forward-looking)
  [BUDGET]  - figure from the computed budget summary
Markers are stripped from the clean output and kept in the annotated one.
"""
from __future__ import annotations

import difflib
import re
from collections import Counter
from dataclasses import dataclass

from .models import Profile, Project, Section

MARKER_RE = re.compile(r"\[(F|P):([A-Za-z0-9_-]+)\]|\[BUDGET\]")
NUMBER_RE = re.compile(r"\d+(?:[.,]\d+)*")
SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")
WORD_RE = re.compile(r"\w+(?:[-'’]\w+)*", re.UNICODE)

# Words asserting that something is done/validated. Citing a non-PROVEN fact
# next to one of these is an overclaim unless a qualifier precedes it.
OVERCLAIM_WORDS = {
    "proven", "validated", "verified", "demonstrated", "certified", "achieved",
    "completed", "complete", "fully", "production-ready", "guaranteed",
    "доведено", "підтверджено", "сертифіковано", "повністю", "завершено",
}
QUALIFIERS = {
    "not", "no", "never", "without", "yet", "partially", "partly", "un",
    "не", "ні", "частково", "ще",
}
QUALIFIER_WINDOW = 4
# Negation after a forbidden phrase ("... certification has not been obtained").
TRAILING_NEGATION_WINDOW = 8


@dataclass(frozen=True)
class Violation:
    section: str
    code: str
    detail: str
    sentence: str = ""

    def as_dict(self) -> dict:
        return {"section": self.section, "code": self.code, "detail": self.detail,
                "sentence": self.sentence}


def normalize_number(raw: str) -> str:
    """Canonical form so equal values compare equal: '45,000' == '45000.0' == '45000'."""
    n = raw.replace(",", "").rstrip(".")
    if "." in n:
        n = n.rstrip("0").rstrip(".")
    return n.lstrip("0") or "0"


def numbers_in(text: str) -> Counter:
    """Multiset of numbers: a sentence may not repeat a number more often than
    its sources do ("19 of 19" is not supported by "18 of 19")."""
    return Counter(normalize_number(m) for m in NUMBER_RE.findall(MARKER_RE.sub(" ", text)))


def strip_markers(text: str) -> str:
    lines = []
    for line in MARKER_RE.sub("", text).splitlines():
        line = re.sub(r"[ \t]+([.,;:!?])", r"\1", line)
        lines.append(re.sub(r"[ \t]{2,}", " ", line).rstrip())
    return "\n".join(lines).strip()


def segments(text: str) -> list[str]:
    """Split into checkable units: sentences, list items; skip headings/blank.

    A fragment consisting only of markers (model wrote them after the full
    stop) is attached to the previous sentence.
    """
    out: list[str] = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        line = re.sub(r"^([-*•]|\d+[.)])\s+", "", line)
        for part in SENTENCE_SPLIT_RE.split(line):
            part = part.strip()
            if not part:
                continue
            if out and not MARKER_RE.sub("", part).strip(" .;,"):
                out[-1] = f"{out[-1]} {part}"
            else:
                out.append(part)
    return out


def _has_unqualified_overclaim(sentence: str) -> str | None:
    words = [w.lower() for w in WORD_RE.findall(MARKER_RE.sub(" ", sentence))]
    for i, w in enumerate(words):
        if w in OVERCLAIM_WORDS:
            window = words[max(0, i - QUALIFIER_WINDOW):i]
            if not any(q in QUALIFIERS or q.endswith("n't") for q in window):
                return w
    return None


def _forbidden_hit(sentence: str, phrase: str) -> bool:
    plain = MARKER_RE.sub(" ", sentence).lower()
    idx = plain.find(phrase.lower())
    if idx < 0:
        return False
    before = WORD_RE.findall(plain[:idx])[-QUALIFIER_WINDOW:]
    after = WORD_RE.findall(plain[idx + len(phrase):])[:TRAILING_NEGATION_WINDOW]
    return not any(q in QUALIFIERS or q.endswith("n't") for q in before + after)


def validate_section(section: Section, text: str, profile: Profile, project: Project,
                     budget: dict) -> list[Violation]:
    v: list[Violation] = []
    sid = section.id
    plain = strip_markers(text)
    if not plain:
        return [Violation(sid, "SECTION_EMPTY", "section has no text")]

    words = len(WORD_RE.findall(plain))
    if section.max_words and words > section.max_words:
        v.append(Violation(sid, "OVER_WORD_LIMIT", f"{words} words > {section.max_words}"))
    if section.max_chars and len(plain) > section.max_chars:
        v.append(Violation(sid, "OVER_CHAR_LIMIT", f"{len(plain)} chars > {section.max_chars}"))

    budget_numbers = Counter(normalize_number(str(x)) for x in _budget_values(budget))

    for sent in segments(text):
        refs = MARKER_RE.findall(sent)
        has_budget = "[BUDGET]" in sent
        if not refs and not has_budget:
            v.append(Violation(sid, "UNCITED_SENTENCE",
                               "sentence has no [F:], [P:] or [BUDGET] marker", sent))
            continue

        allowed_numbers: Counter = Counter()
        cited_facts = []
        for kind, ref_id in refs:
            if not kind:
                continue
            if kind == "F":
                fact = profile.facts.get(ref_id)
                if fact is None:
                    v.append(Violation(sid, "UNKNOWN_FACT", f"[F:{ref_id}] not in profile"
                                       + _did_you_mean("F", ref_id, profile.facts), sent))
                    continue
                cited_facts.append(fact)
                allowed_numbers += numbers_in(fact.text) + numbers_in(fact.as_of)
            else:
                item = project.items.get(ref_id)
                if item is None:
                    v.append(Violation(sid, "UNKNOWN_PLAN_ITEM", f"[P:{ref_id}] not in plan"
                                       + _did_you_mean("P", ref_id, project.items), sent))
                    continue
                allowed_numbers += numbers_in(item.text)
        if has_budget:
            allowed_numbers += budget_numbers

        # The product name (e.g. "1UA-AGE") is a name, not a quantity.
        stray = numbers_in(_without(sent, profile.product)) - allowed_numbers
        if stray:
            v.append(Violation(sid, "NUMBER_NOT_IN_SOURCE",
                               f"numbers {sorted(stray)} not found in cited sources", sent))

        weak = [f.id for f in cited_facts if f.status != "PROVEN"]
        if weak:
            word = _has_unqualified_overclaim(sent)
            if word:
                v.append(Violation(sid, "STATUS_OVERCLAIM",
                                   f"'{word}' used with non-PROVEN facts {weak}", sent))

        for phrase in profile.forbidden_claims:
            if _forbidden_hit(sent, phrase):
                v.append(Violation(sid, "FORBIDDEN_CLAIM", f"forbidden claim '{phrase}'", sent))
    return v


def _without(text: str, name: str) -> str:
    return re.sub(re.escape(name), " ", text, flags=re.IGNORECASE) if name else text


def _did_you_mean(kind: str, ref_id: str, known) -> str:
    close = difflib.get_close_matches(ref_id, list(known), n=1, cutoff=0.6)
    return f"; did you mean [{kind}:{close[0]}]?" if close else ""


def _budget_values(budget: dict):
    for key in ("total_cost", "cofinancing", "requested", "cofinancing_pct"):
        if key in budget:
            yield _fmt(budget[key])
    for d in (budget.get("by_category", {}), budget.get("category_pct", {})):
        for val in d.values():
            yield _fmt(val)
    for line in budget.get("lines", []):
        yield _fmt(line["amount"])


def _fmt(x: float) -> str:
    return str(int(x)) if float(x).is_integer() else str(x)
