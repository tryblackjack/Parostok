"""Typed inputs: product profile (evidence facts), grant call, project plan.

All three are plain YAML files edited by humans. Loading fails loudly on
schema problems instead of guessing defaults.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

FACT_STATUSES = {
    "PROVEN",
    "PARTIALLY_PROVEN",
    "NOT_PROVEN",
    "CONFLICTING_UNRESOLVED",
    "EXTERNAL_EVIDENCE_REQUIRED",
    "PHYSICAL_VALIDATION_REQUIRED",
}


class InputError(ValueError):
    """Raised when an input file violates the schema."""


def _require(data: dict, key: str, where: str) -> Any:
    if key not in data or data[key] in (None, ""):
        raise InputError(f"{where}: missing required field '{key}'")
    return data[key]


@dataclass(frozen=True)
class Fact:
    id: str
    text: str
    status: str
    source: str
    as_of: str
    tags: tuple[str, ...] = ()


@dataclass(frozen=True)
class Profile:
    product: str
    summary: str
    organization: dict[str, Any]
    facts: dict[str, Fact]
    forbidden_claims: tuple[str, ...]
    search: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Section:
    id: str
    title: str
    guidance: str
    max_words: int | None = None
    max_chars: int | None = None
    topics: tuple[str, ...] = ()
    include_budget: bool = False


@dataclass(frozen=True)
class Criterion:
    key: str
    op: str
    value: Any
    label: str


@dataclass(frozen=True)
class Call:
    id: str
    name: str
    synthetic: bool
    language: str
    source_url: str | None
    eligibility: tuple[Criterion, ...]
    budget_rules: dict[str, Any]
    sections: tuple[Section, ...]
    verified: bool = True
    deadline: str | None = None
    aggregator_url: str | None = None
    exclusions: tuple[str, ...] = ()


@dataclass(frozen=True)
class PlanItem:
    id: str
    text: str
    tags: tuple[str, ...] = ()


@dataclass(frozen=True)
class BudgetLine:
    id: str
    category: str
    description: str
    amount: float


@dataclass(frozen=True)
class Project:
    title: str
    placeholder: bool
    items: dict[str, PlanItem]
    currency: str
    budget_lines: tuple[BudgetLine, ...]
    cofinancing: float = 0.0
    extra: dict[str, Any] = field(default_factory=dict)


def _load_yaml(path: Path) -> dict:
    with open(path, encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    if not isinstance(data, dict):
        raise InputError(f"{path}: top level must be a mapping")
    return data


def _check_id(item_id: str, where: str) -> str:
    if not isinstance(item_id, str) or not item_id.replace("-", "").replace("_", "").isalnum():
        raise InputError(f"{where}: id '{item_id}' must be alphanumeric with - or _")
    return item_id


def load_profile(path: Path) -> Profile:
    data = _load_yaml(path)
    where = str(path)
    facts: dict[str, Fact] = {}
    for i, raw in enumerate(_require(data, "facts", where)):
        fw = f"{where}: facts[{i}]"
        fid = _check_id(_require(raw, "id", fw), fw)
        status = _require(raw, "status", fw)
        if status not in FACT_STATUSES:
            raise InputError(f"{fw}: status '{status}' not in {sorted(FACT_STATUSES)}")
        if fid in facts:
            raise InputError(f"{fw}: duplicate fact id '{fid}'")
        facts[fid] = Fact(
            id=fid,
            text=str(_require(raw, "text", fw)).strip(),
            status=status,
            source=str(_require(raw, "source", fw)),
            as_of=str(_require(raw, "as_of", fw)),
            tags=tuple(raw.get("tags") or ()),
        )
    return Profile(
        product=str(_require(data, "product", where)),
        summary=str(_require(data, "summary", where)).strip(),
        organization=dict(data.get("organization") or {}),
        facts=facts,
        forbidden_claims=tuple(data.get("forbidden_claims") or ()),
        search=dict(data.get("search") or {}),
    )


def load_call(path: Path) -> Call:
    data = _load_yaml(path)
    where = str(path)
    sections = []
    seen = set()
    for i, raw in enumerate(_require(data, "sections", where)):
        sw = f"{where}: sections[{i}]"
        sid = _check_id(_require(raw, "id", sw), sw)
        if sid in seen:
            raise InputError(f"{sw}: duplicate section id '{sid}'")
        seen.add(sid)
        sections.append(
            Section(
                id=sid,
                title=str(_require(raw, "title", sw)),
                guidance=str(_require(raw, "guidance", sw)).strip(),
                max_words=raw.get("max_words"),
                max_chars=raw.get("max_chars"),
                topics=tuple(raw.get("topics") or ()),
                include_budget=bool(raw.get("include_budget", False)),
            )
        )
    criteria = []
    for i, raw in enumerate(data.get("eligibility") or ()):
        cw = f"{where}: eligibility[{i}]"
        criteria.append(
            Criterion(
                key=str(_require(raw, "key", cw)),
                op=str(_require(raw, "op", cw)),
                value=raw.get("value"),
                label=str(raw.get("label") or raw["key"]),
            )
        )
    synthetic = bool(data.get("synthetic", False))
    verified = bool(data.get("verified", True))
    source_url = data.get("source_url")
    if not synthetic and verified and not source_url:
        raise InputError(f"{where}: a verified call needs 'source_url' to the official call text")
    return Call(
        id=str(_require(data, "id", where)),
        name=str(_require(data, "name", where)),
        synthetic=synthetic,
        language=str(data.get("language", "en")),
        source_url=source_url,
        eligibility=tuple(criteria),
        budget_rules=dict(data.get("budget") or {}),
        sections=tuple(sections),
        verified=verified,
        deadline=str(data["deadline"]) if data.get("deadline") else None,
        aggregator_url=data.get("aggregator_url"),
        exclusions=tuple(str(e) for e in data.get("exclusions") or ()),
    )


def load_project(path: Path) -> Project:
    data = _load_yaml(path)
    where = str(path)
    items: dict[str, PlanItem] = {}
    for i, raw in enumerate(_require(data, "plan", where)):
        pw = f"{where}: plan[{i}]"
        pid = _check_id(_require(raw, "id", pw), pw)
        if pid in items:
            raise InputError(f"{pw}: duplicate plan id '{pid}'")
        items[pid] = PlanItem(id=pid, text=str(_require(raw, "text", pw)).strip(),
                              tags=tuple(raw.get("tags") or ()))
    budget = data.get("budget") or {}
    lines = []
    for i, raw in enumerate(budget.get("lines") or ()):
        bw = f"{where}: budget.lines[{i}]"
        amount = _require(raw, "amount", bw)
        if not isinstance(amount, (int, float)) or amount < 0:
            raise InputError(f"{bw}: amount must be a non-negative number")
        lines.append(BudgetLine(
            id=_check_id(_require(raw, "id", bw), bw),
            category=str(_require(raw, "category", bw)),
            description=str(_require(raw, "description", bw)),
            amount=float(amount),
        ))
    return Project(
        title=str(_require(data, "title", where)),
        placeholder=bool(data.get("placeholder", False)),
        items=items,
        currency=str(budget.get("currency", "")),
        budget_lines=tuple(lines),
        cofinancing=float(budget.get("cofinancing", 0) or 0),
    )
