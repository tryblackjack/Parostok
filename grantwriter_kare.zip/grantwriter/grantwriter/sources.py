"""Grant opportunity discovery from aggregators.

grant.market: RSS feed for the list, then each opportunity page for the
schema.org MonetaryGrant JSON-LD (amount, currency, deadline, funder) and the
`opt-*` section blocks (audience, conditions, requirements, links).

Aggregator content is input for screening only. grant.market's robots.txt
declares `ai-train=no`: fetched text must not go into model training data.
"""
from __future__ import annotations

import hashlib
import html
import json
import re
import time
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass, field
from datetime import date
from html.parser import HTMLParser
from urllib.parse import urlparse

USER_AGENT = "grantwriter/0.1 (grant screening; contact: repository owner)"

SOURCES = {
    "grant.market": {
        "feed": "https://grant.market/rss.xml",
        "host": "grant.market",
        "usage_policy": "robots.txt Content-Signal: search=yes, ai-input=yes, ai-train=no",
    },
}


@dataclass
class Opportunity:
    id: str
    title: str
    url: str
    published: str
    summary: str
    source: str
    amount_max: float | None = None
    currency: str | None = None
    deadline: str | None = None
    funder: str | None = None
    sections: dict[str, str] = field(default_factory=dict)
    external_links: list[str] = field(default_factory=list)
    page_sha256: str | None = None


def http_get(url: str, timeout: float = 30.0) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def parse_rss(xml_bytes: bytes, source: str) -> list[Opportunity]:
    channel = ET.fromstring(xml_bytes).find("channel")
    out = []
    for item in channel.findall("item") if channel is not None else ():
        def text(tag):
            el = item.find(tag)
            return (el.text or "").strip() if el is not None else ""
        link = text("link")
        out.append(Opportunity(id=text("guid") or link, title=text("title"), url=link,
                               published=text("pubDate"), summary=text("description"),
                               source=source))
    return out


class _PageParser(HTMLParser):
    """Collects JSON-LD scripts and the text of `<div id="opt-*">` blocks."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.jsonld: list[str] = []
        self.blocks: dict[str, list[str]] = {}
        self.links: dict[str, list[str]] = {}
        self._in_jsonld = False
        self._block: str | None = None
        self._depth = 0
        self._in_h2 = False
        self._title: list[str] = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "script" and a.get("type") == "application/ld+json":
            self._in_jsonld = True
            self.jsonld.append("")
            return
        if self._block is None:
            if tag == "div" and (a.get("id") or "").startswith("opt-"):
                self._block, self._depth, self._title = a["id"][4:], 1, []
                self.blocks[self._block] = []
                self.links[self._block] = []
            return
        if tag == "div":
            self._depth += 1
        elif tag == "h2":
            self._in_h2 = True
        elif tag == "a" and a.get("href"):
            self.links[self._block].append(a["href"])
        elif tag in ("li", "p", "br"):
            self.blocks[self._block].append("\n")

    def handle_endtag(self, tag):
        if tag == "script":
            self._in_jsonld = False
        elif self._block is not None:
            if tag == "h2":
                self._in_h2 = False
            elif tag == "div":
                self._depth -= 1
                if self._depth == 0:
                    title = "".join(self._title).strip() or self._block
                    body = re.sub(r"[ \t ]+", " ", "".join(self.blocks.pop(self._block)))
                    body = "\n".join(l.strip() for l in body.splitlines() if l.strip())
                    self.blocks[title] = body
                    self.links[title] = self.links.pop(self._block)
                    self._block = None

    def handle_data(self, data):
        if self._in_jsonld:
            self.jsonld[-1] += data
        elif self._block is not None:
            (self._title if self._in_h2 else self.blocks[self._block]).append(data)


def _first(value) -> dict:
    """JSON-LD allows a single object or a list of them."""
    if isinstance(value, list):
        value = next((v for v in value if isinstance(v, dict)), None)
    return value if isinstance(value, dict) else {}


def enrich_from_page(opp: Opportunity, page: bytes, host: str) -> Opportunity:
    opp.page_sha256 = hashlib.sha256(page).hexdigest()
    parser = _PageParser()
    parser.feed(page.decode("utf-8", errors="replace"))
    for raw in parser.jsonld:
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict) and data.get("@type") == "MonetaryGrant":
            amount = _first(data.get("amount"))
            opp.amount_max = amount.get("maxValue")
            opp.currency = amount.get("currency")
            opp.deadline = amount.get("validThrough") or (
                _first(data.get("potentialAction")).get("endTime") or "")[:10] or None
            funders = data.get("funder") or []
            funders = funders if isinstance(funders, list) else [funders]
            names = [f.get("name") for f in funders if isinstance(f, dict) and f.get("name")]
            opp.funder = "; ".join(names) or None
    opp.sections = {k: v for k, v in parser.blocks.items() if v}
    links = []
    for hrefs in parser.links.values():
        for href in hrefs:
            href = html.unescape(href)
            netloc = urlparse(href).netloc
            if href.startswith("http") and host not in netloc and href not in links:
                links.append(href)
    opp.external_links = links
    return opp


def discover(source: str = "grant.market", limit: int | None = None, delay: float = 1.0,
             fetch=http_get) -> list[Opportunity]:
    cfg = SOURCES[source]
    opps = parse_rss(fetch(cfg["feed"]), source)[:limit]
    for i, opp in enumerate(opps):
        if i:
            time.sleep(delay)  # be polite to the aggregator
        try:
            enrich_from_page(opp, fetch(opp.url), cfg["host"])
        except (OSError, ValueError, AttributeError, TypeError) as exc:
            # Typed per-page failure; the rest of the run continues.
            opp.sections["_fetch_error"] = f"{type(exc).__name__}: {exc}"
    return opps


@dataclass
class Screening:
    opportunity_id: str
    title: str
    url: str
    deadline: str | None
    amount: str
    status: str            # CANDIDATE | EXCLUDED | EXPIRED
    score: int
    matched: list[str]
    excluded_by: list[str]
    flags: list[str]


def _variants(phrase: str) -> set[str]:
    """'deep tech' also matches 'deeptech' and 'deep-tech'."""
    return {phrase, phrase.replace(" ", ""), phrase.replace(" ", "-")}


def screen(opps: list[Opportunity], search: dict, today: date) -> list[Screening]:
    """Deterministic keyword screening against the profile's `search` block.

    Topic keywords are matched in the title and summary only: full page text
    carries site boilerplate (e.g. "електронна пошта") that matches almost any
    stem. Full page text is used for requirement flags.
    """
    keywords = [k.lower() for k in search.get("keywords", [])]
    min_score = int(search.get("min_score", 1))
    exclude = [k.lower() for k in search.get("exclude", [])]
    flag_rules = {k: [w.lower() for w in v] for k, v in (search.get("flags") or {}).items()}
    out = []
    for o in opps:
        topic_text = f"{o.title} {o.summary}".lower()
        text = " ".join([topic_text, *o.sections.values()]).lower()
        matched = [k for k in keywords if any(v in topic_text for v in _variants(k))]
        excluded_by = [k for k in exclude if k in o.title.lower() or k in o.summary.lower()]
        flags = [name for name, words in flag_rules.items() if any(w in text for w in words)]
        if o.deadline is None:
            flags.append("DEADLINE_UNKNOWN")
        if o.deadline and o.deadline[:10] < today.isoformat():
            status = "EXPIRED"
        elif excluded_by or len(matched) < min_score:
            status = "EXCLUDED"
        else:
            status = "CANDIDATE"
        amount = f"{o.amount_max:,.0f} {o.currency}".replace(",", " ") if o.amount_max else "n/a"
        out.append(Screening(o.id, o.title, o.url, o.deadline, amount, status, len(matched),
                             matched, excluded_by, flags))
    order = {"CANDIDATE": 0, "EXCLUDED": 1, "EXPIRED": 2}
    out.sort(key=lambda s: (order[s.status], -s.score, s.deadline or "9999"))
    return out


def call_skeleton(opp: Opportunity) -> dict:
    """Unverified call stub. Eligibility and sections must be completed from the
    official call text; the pipeline reports CALL_NOT_VERIFIED until then."""
    budget = {}
    if opp.currency:
        budget["currency"] = opp.currency
    if opp.amount_max:
        budget["max_request"] = opp.amount_max
    return {
        "id": re.sub(r"[^A-Za-z0-9_-]", "-", opp.url.rstrip("/").rsplit("/", 1)[-1]) or opp.id,
        "name": opp.title,
        "synthetic": False,
        "verified": False,
        "language": "uk",
        "source_url": None,
        "aggregator_url": opp.url,
        "official_link_candidates": opp.external_links,
        "deadline": opp.deadline,
        "funder": opp.funder,
        "eligibility": [],
        "budget": budget,
        "aggregator_notes": opp.sections,
        "sections": [
            {"id": "summary", "title": "Резюме проєкту",
             "guidance": "Replace with the official form's sections and limits.",
             "max_words": 200, "topics": ["core"]},
        ],
    }


def to_json(opps: list[Opportunity]) -> list[dict]:
    return [asdict(o) for o in opps]


def from_json(rows: list[dict]) -> list[Opportunity]:
    return [Opportunity(**r) for r in rows]
