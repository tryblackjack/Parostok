"""Evidence-bound grant application writer."""
__version__ = "0.1.0"
