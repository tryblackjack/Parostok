"""Deterministic gates: eligibility and budget. No model involvement."""
from __future__ import annotations

from dataclasses import dataclass

from .models import Call, Profile, Project

PASS, FAIL, UNKNOWN = "PASS", "FAIL", "UNKNOWN"


@dataclass(frozen=True)
class CheckResult:
    id: str
    label: str
    result: str
    detail: str

    def as_dict(self) -> dict:
        return {"id": self.id, "label": self.label, "result": self.result, "detail": self.detail}


def _compare(op: str, actual, expected) -> bool:
    if op == "eq":
        return actual == expected
    if op == "in":
        return actual in expected
    if op == "not_in":
        return actual not in expected
    if op == "gte":
        return actual >= expected
    if op == "lte":
        return actual <= expected
    if op == "true":
        return actual is True
    raise ValueError(f"unknown eligibility op '{op}'")


def check_eligibility(profile: Profile, call: Call) -> list[CheckResult]:
    results = []
    for c in call.eligibility:
        actual = profile.organization.get(c.key)
        if actual is None:
            results.append(CheckResult(c.key, c.label, UNKNOWN,
                                       f"organization.{c.key} is not set in the profile"))
            continue
        try:
            ok = _compare(c.op, actual, c.value)
        except TypeError as exc:
            results.append(CheckResult(c.key, c.label, FAIL, f"type mismatch: {exc}"))
            continue
        results.append(CheckResult(c.key, c.label, PASS if ok else FAIL,
                                   f"{c.key}={actual!r} {c.op} {c.value!r}"))
    return results


def budget_summary(project: Project) -> dict:
    by_cat: dict[str, float] = {}
    for line in project.budget_lines:
        by_cat[line.category] = by_cat.get(line.category, 0.0) + line.amount
    total = sum(by_cat.values())
    requested = total - project.cofinancing
    return {
        "currency": project.currency,
        "total_cost": round(total, 2),
        "cofinancing": round(project.cofinancing, 2),
        "requested": round(requested, 2),
        "cofinancing_pct": round(100 * project.cofinancing / total, 1) if total else 0.0,
        "by_category": {k: round(v, 2) for k, v in sorted(by_cat.items())},
        "category_pct": {k: round(100 * v / total, 1) if total else 0.0
                         for k, v in sorted(by_cat.items())},
        "lines": [{"id": l.id, "category": l.category, "description": l.description,
                   "amount": l.amount} for l in project.budget_lines],
    }


def check_budget(project: Project, call: Call, summary: dict) -> list[CheckResult]:
    rules = call.budget_rules
    results = []
    if not project.budget_lines:
        if rules:
            results.append(CheckResult("budget_lines", "Budget has lines", FAIL, "no budget lines"))
        return results
    if "currency" in rules:
        ok = project.currency == rules["currency"]
        results.append(CheckResult("currency", "Currency matches call", PASS if ok else FAIL,
                                   f"{project.currency!r} vs {rules['currency']!r}"))
    if "max_request" in rules:
        ok = summary["requested"] <= rules["max_request"]
        results.append(CheckResult("max_request", "Requested amount within cap",
                                   PASS if ok else FAIL,
                                   f"requested {summary['requested']} <= {rules['max_request']}"))
    if "min_request" in rules:
        ok = summary["requested"] >= rules["min_request"]
        results.append(CheckResult("min_request", "Requested amount above floor",
                                   PASS if ok else FAIL,
                                   f"requested {summary['requested']} >= {rules['min_request']}"))
    if "cofinancing_min_pct" in rules:
        ok = summary["cofinancing_pct"] >= rules["cofinancing_min_pct"]
        results.append(CheckResult("cofinancing", "Co-financing share", PASS if ok else FAIL,
                                   f"{summary['cofinancing_pct']}% >= {rules['cofinancing_min_pct']}%"))
    allowed = rules.get("allowed_categories")
    for cat, pct in summary["category_pct"].items():
        if allowed is not None and cat not in allowed:
            results.append(CheckResult(f"category:{cat}", f"Category '{cat}' allowed", FAIL,
                                       f"not in {allowed}"))
        cap = (rules.get("category_caps_pct") or {}).get(cat)
        if cap is not None:
            results.append(CheckResult(f"cap:{cat}", f"Category '{cat}' share",
                                       PASS if pct <= cap else FAIL, f"{pct}% <= {cap}%"))
    return results
