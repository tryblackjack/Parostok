"""CLI.

  python -m grantwriter discover --profile P --out DIR [--limit N]
  python -m grantwriter skeleton --opportunities DIR/opportunities.json --id ID --out call.yaml
  python -m grantwriter check --profile P --call C [--project J]
  python -m grantwriter draft --profile P --call C --project J --out DIR [--backend local --model M]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import date, datetime, timezone
from pathlib import Path

from . import sources
from .drafters import (DEFAULT_BASE_URL, AnthropicBackend, ModelDrafter, OfflineDrafter,
                       OpenAICompatibleBackend)
from .models import InputError, load_call, load_profile, load_project
from .pipeline import BLOCKED, INVALID, gates, run


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="grantwriter")
    sub = parser.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("draft", help="draft and validate an application")
    d.add_argument("--profile", type=Path, required=True)
    d.add_argument("--call", type=Path, required=True)
    d.add_argument("--project", type=Path, required=True)
    d.add_argument("--out", type=Path, required=True)
    d.add_argument("--backend", choices=["offline", "openai-compatible", "anthropic"],
                   default="offline",
                   help="offline: deterministic; openai-compatible: local server by default "
                        "(Ollama, llama.cpp, vLLM, LM Studio) or any compatible cloud API; "
                        "anthropic: Claude via the official SDK")
    d.add_argument("--model", help="model name (required for model backends)")
    d.add_argument("--base-url", default=DEFAULT_BASE_URL,
                   help="OpenAI-compatible endpoint, default: local Ollama")
    d.add_argument("--api-key-env", help="name of the env var holding the API key (cloud only)")
    d.add_argument("--max-repairs", type=int, default=2)

    f = sub.add_parser("discover", help="fetch and screen opportunities from an aggregator")
    f.add_argument("--profile", type=Path, required=True)
    f.add_argument("--source", choices=sorted(sources.SOURCES), default="grant.market")
    f.add_argument("--out", type=Path, required=True)
    f.add_argument("--limit", type=int)
    f.add_argument("--cached", type=Path,
                   help="re-screen a saved opportunities.json instead of fetching again")

    k = sub.add_parser("skeleton", help="write an unverified call YAML for one opportunity")
    k.add_argument("--opportunities", type=Path, required=True)
    k.add_argument("--id", required=True, help="opportunity id or URL slug")
    k.add_argument("--out", type=Path, required=True)

    c = sub.add_parser("check", help="eligibility and exclusion gates only, no drafting")
    c.add_argument("--profile", type=Path, required=True)
    c.add_argument("--call", type=Path, required=True)
    c.add_argument("--project", type=Path, help="optional; adds budget gates")

    args = parser.parse_args(argv)
    if args.cmd == "check":
        return _check(args)
    if args.cmd == "discover":
        return _discover(args)
    if args.cmd == "skeleton":
        return _skeleton(args)

    if args.backend == "offline":
        drafter = OfflineDrafter()
    else:
        if not args.model:
            parser.error(f"--backend {args.backend} requires --model")
        backend = (OpenAICompatibleBackend(args.model, args.base_url, args.api_key_env)
                   if args.backend == "openai-compatible" else AnthropicBackend(args.model))
        drafter = ModelDrafter(backend, max_repairs=args.max_repairs)
    try:
        report = run(args.profile, args.call, args.project, args.out, drafter)
    except InputError as exc:
        print(f"INPUT_ERROR: {exc}", file=sys.stderr)
        return 2

    print(f"STATUS: {report['status']}")
    for b in report["blockers"]:
        print(f"  BLOCKER   {b}")
    for o in report["open_items"]:
        print(f"  OPEN ITEM {o}")
    for s in report["sections"]:
        last = s["attempts"][-1]
        print(f"  section {s['id']}: attempts={len(s['attempts'])} "
              f"violations={len(last['violations'])}")
        for v in last["violations"]:
            print(f"    - {v['code']}: {v['detail']}")
    print(f"Output: {args.out}")
    return 1 if report["status"] in (BLOCKED, INVALID) else 0


def _check(args) -> int:
    try:
        profile, call = load_profile(args.profile), load_call(args.call)
        project = load_project(args.project) if args.project else None
    except InputError as exc:
        print(f"INPUT_ERROR: {exc}", file=sys.stderr)
        return 2
    eligibility, _, budget_checks, open_items, blockers = gates(profile, call, project, date.today())
    status = "BLOCKED" if blockers else ("OPEN_ITEMS" if open_items else "PASS")
    print(f"CHECK: {status}  ({call.name})")
    for r in [*eligibility, *budget_checks]:
        print(f"  {r.result:<7} {r.label}: {r.detail}")
    for b in blockers:
        print(f"  BLOCKER   {b}")
    for o in open_items:
        print(f"  OPEN ITEM {o}")
    return 1 if blockers else 0


def _discover(args) -> int:
    profile = load_profile(args.profile)
    if args.cached:
        saved = json.loads(args.cached.read_text(encoding="utf-8"))
        opps = sources.from_json(saved["opportunities"])
    else:
        saved = {
            "source": args.source,
            "usage_policy": sources.SOURCES[args.source]["usage_policy"],
            "fetched_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }
        opps = sources.discover(args.source, limit=args.limit)
    rows = sources.screen(opps, profile.search, date.today())
    args.out.mkdir(parents=True, exist_ok=True)
    opp_path = args.out / "opportunities.json"
    if not (args.cached and args.cached.resolve() == opp_path.resolve()):
        opp_path.write_text(json.dumps({**{k: v for k, v in saved.items() if k != "opportunities"},
                                        "opportunities": sources.to_json(opps)},
                                       ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [f"# Screening: {args.source}, {date.today().isoformat()}\n",
             "Keyword screening only. A CANDIDATE still needs the official call text checked.\n",
             "| Status | Score | Deadline | Amount | Title | Flags |", "|---|---|---|---|---|---|"]
    for r in rows:
        lines.append(f"| {r.status} | {r.score} | {r.deadline or '?'} | {r.amount} | "
                     f"[{r.title}]({r.url}) | {', '.join(r.flags)} |")
    (args.out / "shortlist.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (args.out / "screening.json").write_text(
        json.dumps([r.__dict__ for r in rows], ensure_ascii=False, indent=2), encoding="utf-8")
    sums = "".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n"
                   for p in sorted(args.out.glob("*")) if p.name != "SHA256SUMS")
    (args.out / "SHA256SUMS").write_text(sums, encoding="utf-8")
    counts = {s: sum(r.status == s for r in rows) for s in ("CANDIDATE", "EXCLUDED", "EXPIRED")}
    print(f"Fetched {len(opps)} opportunities: {counts}")
    for r in rows:
        if r.status == "CANDIDATE":
            print(f"  [{r.score}] {r.deadline or '?'} {r.amount:>16}  {r.title}")
    print(f"Output: {args.out}")
    return 0


def _skeleton(args) -> int:
    import yaml
    data = json.loads(args.opportunities.read_text(encoding="utf-8"))
    opps = sources.from_json(data["opportunities"])
    match = [o for o in opps if args.id in (o.id, o.url.rstrip("/").rsplit("/", 1)[-1])]
    if not match:
        print(f"no opportunity with id or slug '{args.id}'", file=sys.stderr)
        return 2
    args.out.parent.mkdir(parents=True, exist_ok=True)
    header = ("# UNVERIFIED call skeleton generated from an aggregator page.\n"
              "# Fill eligibility, budget rules and sections from the official call text,\n"
              "# set source_url to it, then set verified: true.\n")
    args.out.write_text(header + yaml.safe_dump(sources.call_skeleton(match[0]),
                                                allow_unicode=True, sort_keys=False),
                        encoding="utf-8")
    print(f"Wrote {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
