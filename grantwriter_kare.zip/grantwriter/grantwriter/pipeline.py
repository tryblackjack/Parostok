"""Application pipeline: gates -> drafting -> validation -> evidence package."""
from __future__ import annotations

import hashlib
import json
from datetime import date, datetime, timezone
from pathlib import Path

from . import __version__
from .checks import FAIL, UNKNOWN, budget_summary, check_budget, check_eligibility
from .models import load_call, load_profile, load_project
from .validate import strip_markers, validate_section

BLOCKED = "APPLICATION_BLOCKED"
INVALID = "APPLICATION_DRAFT_INVALID"
VALID_OPEN = "APPLICATION_DRAFT_VALID_WITH_OPEN_ITEMS"
VALID = "APPLICATION_DRAFT_VALID"

SCOPE_NOTE = ("A valid draft means the text passed deterministic evidence, limit and budget "
              "checks. It is not a submitted application, not a funding decision and not a "
              "substitute for human review of the official call text.")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def gates(profile, call, project, today: date):
    """Deterministic pre-drafting gates. `project` may be None (eligibility-only check)."""
    eligibility = check_eligibility(profile, call)
    budget = budget_summary(project) if project else {}
    budget_checks = check_budget(project, call, budget) if project else []

    open_items: list[str] = []
    if call.synthetic:
        open_items.append("CALL_IS_SYNTHETIC: requirements are an example, not an official call")
    if not call.verified:
        open_items.append("CALL_NOT_VERIFIED: requirements not yet checked against the official "
                          f"call text (aggregator: {call.aggregator_url})")
    if project and project.placeholder:
        open_items.append("PROJECT_PLAN_PLACEHOLDER: plan and budget figures are placeholders")
    open_items += [f"ELIGIBILITY_UNKNOWN: {c.label} ({c.detail})"
                   for c in eligibility if c.result == UNKNOWN]
    # Exclusions a rule engine cannot decide (e.g. "no pilot projects") are never
    # passed silently: each needs an explicit human or reviewed decision.
    open_items += [f"EXCLUSION_CHECK_REQUIRED: {e}" for e in call.exclusions]

    blockers = [f"ELIGIBILITY_FAIL: {c.label} ({c.detail})" for c in eligibility if c.result == FAIL]
    if call.deadline and call.deadline[:10] < today.isoformat():
        blockers.append(f"DEADLINE_PASSED: {call.deadline}")
    blockers += [f"BUDGET_FAIL: {c.label} ({c.detail})" for c in budget_checks if c.result == FAIL]
    return eligibility, budget, budget_checks, open_items, blockers


def run(profile_path: Path, call_path: Path, project_path: Path, out_dir: Path, drafter,
        today: date | None = None) -> dict:
    today = today or date.today()
    profile = load_profile(profile_path)
    call = load_call(call_path)
    project = load_project(project_path)
    out_dir.mkdir(parents=True, exist_ok=True)

    eligibility, budget, budget_checks, open_items, blockers = gates(profile, call, project, today)

    drafts = []
    if not blockers:
        for section in call.sections:
            def validate(text, section=section):
                return validate_section(section, text, profile, project, budget)
            drafts.append((section, drafter.draft(section, profile, project, call, budget, validate)))

    remaining = [v for _, d in drafts for v in d.final.violations]
    if blockers:
        status = BLOCKED
    elif remaining:
        status = INVALID
    elif open_items:
        status = VALID_OPEN
    else:
        status = VALID

    outputs: list[Path] = []
    if drafts:
        clean, annotated = [f"# {project.title}\n", f"_{call.name}_\n"], [f"# {project.title} (annotated)\n"]
        for section, d in drafts:
            clean += [f"\n## {section.title}\n", strip_markers(d.final.text) + "\n"]
            annotated += [f"\n## {section.title}\n", d.final.text + "\n"]
        for name, body in (("application.md", clean), ("application.annotated.md", annotated)):
            p = out_dir / name
            p.write_text("".join(body), encoding="utf-8")
            outputs.append(p)

    report = {
        "status": status,
        "scope_note": SCOPE_NOTE,
        "blockers": blockers,
        "open_items": open_items,
        "eligibility": [c.as_dict() for c in eligibility],
        "budget": budget,
        "budget_checks": [c.as_dict() for c in budget_checks],
        "sections": [{
            "id": s.id,
            "backend": d.backend, "model": d.model, "served_model": d.served_model,
            "stop_reason": d.stop_reason,
            "attempts": [{"n": i + 1, "violations": [v.as_dict() for v in a.violations],
                          "text_sha256": hashlib.sha256(a.text.encode()).hexdigest()}
                         for i, a in enumerate(d.attempts)],
            "final_valid": not d.final.violations,
        } for s, d in drafts],
    }
    report_path = out_dir / "report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    outputs.append(report_path)

    manifest = {
        "tool": "grantwriter",
        "tool_version": __version__,
        "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "status": status,
        "drafter": getattr(drafter, "name", type(drafter).__name__),
        "inputs": {role: {"path": str(p), "sha256": sha256_file(p)}
                   for role, p in (("profile", profile_path), ("call", call_path),
                                   ("project", project_path))},
        "outputs": {p.name: sha256_file(p) for p in outputs},
    }
    manifest_path = out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    outputs.append(manifest_path)

    sums = "".join(f"{sha256_file(p)}  {p.name}\n" for p in outputs)
    (out_dir / "SHA256SUMS").write_text(sums, encoding="utf-8")
    return report
