"""Section drafters.

OfflineDrafter - deterministic baseline, assembles cited facts/plan items.
ModelDrafter   - a pluggable model writes prose; validator violations are fed
                 back as a new user turn (append-only) for a bounded repair.
Backends: OpenAICompatibleBackend (local by default, or any compatible cloud
endpoint) and AnthropicBackend (optional SDK).
"""
from __future__ import annotations

import json
import os
import urllib.request
from dataclasses import dataclass, field

from .models import Call, Profile, Project, Section
from .validate import WORD_RE, Violation, strip_markers

DEFAULT_BASE_URL = "http://localhost:11434/v1"

SYSTEM_PROMPT = """You draft sections of grant applications from a closed set of evidence.

Rules (a deterministic validator enforces them; violations are sent back to you):
1. Every sentence and every list item ends with at least one marker before its final punctuation:
   [F:ID] for a fact from the product profile, [P:ID] for a project-plan item, [BUDGET] for a figure from the budget summary.
2. Use only information in the provided facts, plan and budget. Do not add numbers, partners, customers, certifications, awards or results that are not there.
3. Every number you write must appear in a source you cite in the same sentence.
4. Respect each fact's status. Only PROVEN facts may be described as achieved, validated or demonstrated. Describe PARTIALLY_PROVEN, NOT_PROVEN, EXTERNAL_EVIDENCE_REQUIRED and PHYSICAL_VALIDATION_REQUIRED facts as limitations, ongoing work or planned validation. Reviewers reward an honest evidence position.
5. Plan items describe future work: use future or intent wording ("will", "plans to").
6. Stay within the word limit. Write persuasive, concrete, reviewer-oriented prose in the requested language.
7. Never use these phrases unless negated: {forbidden}.
8. Output only the section body in Markdown. No title heading, no preamble, no commentary."""


@dataclass
class Attempt:
    text: str
    violations: list[Violation] = field(default_factory=list)


@dataclass
class DraftResult:
    section_id: str
    attempts: list[Attempt]
    backend: str
    model: str | None = None
    served_model: str | None = None
    stop_reason: str | None = None

    @property
    def final(self) -> Attempt:
        return self.attempts[-1]


def _relevant(section: Section, profile: Profile, project: Project):
    topics = set(section.topics)
    facts = [f for f in profile.facts.values() if not topics or topics & set(f.tags)]
    items = [p for p in project.items.values() if not topics or topics & set(p.tags)]
    return facts, items


class OfflineDrafter:
    """Deterministic: one cited sentence per relevant fact/plan item.

    Produces stilted but always-traceable text; used for tests, dry runs and
    as a baseline that the model-written draft must beat.
    """
    name = "offline"

    def draft(self, section, profile, project, call, budget, validate) -> DraftResult:
        facts, items = _relevant(section, profile, project)
        lines: list[str] = []
        for f in facts:
            suffix = "" if f.status == "PROVEN" else f" (status: {f.status.replace('_', ' ').lower()})"
            lines.append(f"{f.text.rstrip('.')}{suffix} [F:{f.id}].")
        for p in items:
            lines.append(f"Planned: {p.text.rstrip('.')} [P:{p.id}].")
        if section.include_budget and budget.get("lines"):
            cur = budget["currency"]
            lines.append(f"Total cost {_n(budget['total_cost'])} {cur}, requested "
                         f"{_n(budget['requested'])} {cur} [BUDGET].")
            for cat, amount in budget["by_category"].items():
                lines.append(f"- {cat}: {_n(amount)} {cur} [BUDGET]")
        if section.max_words:
            while lines and len(WORD_RE.findall(strip_markers("\n".join(lines)))) > section.max_words:
                lines.pop()
        text = "\n".join(lines)
        return DraftResult(section.id, [Attempt(text, validate(text))], backend=self.name)


def _plain_numbers(value):
    """45000.0 -> 45000 so the model copies the same figure the validator expects."""
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, dict):
        return {k: _plain_numbers(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_plain_numbers(v) for v in value]
    return value


def _n(x: float) -> str:
    return str(int(x)) if float(x).is_integer() else str(x)


@dataclass
class ChatResult:
    text: str
    finish: str | None      # "stop" | "length" | "refusal" | provider value
    served_model: str | None


class OpenAICompatibleBackend:
    """Any OpenAI-compatible /chat/completions endpoint, stdlib HTTP only.

    Local by default (Ollama at http://localhost:11434/v1; also llama.cpp
    server, LM Studio, vLLM). Pointing base_url at a cloud provider and
    naming an API-key environment variable makes it a cloud backend; the key
    itself is never stored in config or run records.
    """

    def __init__(self, model: str, base_url: str = DEFAULT_BASE_URL,
                 api_key_env: str | None = None, temperature: float = 0.2,
                 timeout: float = 600.0, transport=None):
        self.name = "openai-compatible"
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.api_key_env = api_key_env
        self.temperature = temperature
        self.timeout = timeout
        self.transport = transport or self._http_post

    def _http_post(self, url: str, payload: dict) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key_env:
            key = os.environ.get(self.api_key_env)
            if not key:
                raise OSError(f"environment variable {self.api_key_env} is not set")
            headers["Authorization"] = f"Bearer {key}"
        req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers)
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def chat(self, system: str, messages: list[dict]) -> ChatResult:
        data = self.transport(f"{self.base_url}/chat/completions", {
            "model": self.model,
            "messages": [{"role": "system", "content": system}, *messages],
            "temperature": self.temperature,
            "stream": False,
        })
        choice = data["choices"][0]
        return ChatResult((choice["message"].get("content") or "").strip(),
                          choice.get("finish_reason"), data.get("model"))


class AnthropicBackend:
    """Claude through the official Anthropic SDK (optional dependency).

    For product customers who choose a cloud model; not used in-house.
    """

    def __init__(self, model: str = "claude-opus-5-5", effort: str = "high", client=None):
        if client is None:
            import anthropic  # optional, installed only by customers who use it
            client = anthropic.Anthropic()
        self.name = "anthropic"
        self.model = model
        self.effort = effort
        self.client = client

    def chat(self, system: str, messages: list[dict]) -> ChatResult:
        response = self.client.beta.messages.create(
            model=self.model,
            max_tokens=16000,
            system=system,
            output_config={"effort": self.effort},
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",
            messages=messages,
        )
        text = "".join(b.text for b in response.content if b.type == "text").strip()
        finish = {"end_turn": "stop", "max_tokens": "length"}.get(response.stop_reason,
                                                                  response.stop_reason)
        return ChatResult(text, finish, getattr(response, "model", None))


BACKEND_ERRORS: tuple[type[BaseException], ...] = (OSError, KeyError, IndexError, ValueError)
try:  # typed SDK errors, when the optional SDK is installed
    import anthropic as _anthropic
    BACKEND_ERRORS += (_anthropic.APIError,)
except ImportError:
    pass


class ModelDrafter:
    """Model writes, the deterministic validator decides.

    Backend-agnostic: whatever model the user plugs in, the same rules,
    validator and bounded repair loop apply.
    """

    def __init__(self, backend, max_repairs: int = 2):
        self.backend = backend
        self.max_repairs = max_repairs
        self.name = f"model:{backend.name}"

    def _context(self, section: Section, profile: Profile, project: Project, call: Call,
                 budget: dict) -> str:
        facts, items = _relevant(section, profile, project)
        payload = {
            "call": {"name": call.name, "language": call.language},
            "section": {"id": section.id, "title": section.title, "guidance": section.guidance,
                        "max_words": section.max_words, "max_chars": section.max_chars},
            # The summary is not sent: everything the model may state must be a
            # citable fact, so the product description lives in the facts.
            "product": {"name": profile.product},
            "facts": [{"marker": f"[F:{f.id}]", "status": f.status, "text": f.text,
                       "as_of": f.as_of} for f in facts],
            "plan": [{"marker": f"[P:{p.id}]", "text": p.text} for p in items],
        }
        if section.include_budget:
            payload["budget"] = _plain_numbers(budget)
            payload["budget_marker"] = "[BUDGET]"
        return ("Draft this grant application section. Copy markers exactly as given in "
                "the 'marker' fields. Inputs as JSON:\n\n"
                + json.dumps(payload, ensure_ascii=False, indent=2))

    @staticmethod
    def _repair_prompt(violations, section, profile, project) -> str:
        facts, items = _relevant(section, profile, project)
        allowed = [f"[F:{f.id}]" for f in facts] + [f"[P:{p.id}]" for p in items]
        if section.include_budget:
            allowed.append("[BUDGET]")
        return ("The validator rejected this draft. Rewrite the whole section so that every "
                "violation is fixed, keeping all rules. The only valid markers are: "
                + ", ".join(allowed) + ".\nViolations as JSON:\n\n"
                + json.dumps([x.as_dict() for x in violations], ensure_ascii=False, indent=2))

    def draft(self, section, profile, project, call, budget, validate) -> DraftResult:
        system = SYSTEM_PROMPT.format(
            forbidden=", ".join(f'"{p}"' for p in profile.forbidden_claims) or "(none)")
        messages = [{"role": "user",
                     "content": self._context(section, profile, project, call, budget)}]
        result = DraftResult(section.id, [], backend=self.name, model=self.backend.model)
        for attempt_no in range(self.max_repairs + 1):
            try:
                reply = self.backend.chat(system, messages)
            except BACKEND_ERRORS as exc:
                result.attempts.append(Attempt("", [Violation(section.id, "MODEL_UNAVAILABLE",
                                                              f"{type(exc).__name__}: {exc}")]))
                break
            result.served_model, result.stop_reason = reply.served_model, reply.finish
            if reply.finish == "refusal":
                result.attempts.append(Attempt(reply.text, [Violation(
                    section.id, "MODEL_REFUSAL", "model declined the request")]))
                break
            violations = validate(reply.text)
            if reply.finish == "length":
                violations.append(Violation(section.id, "TRUNCATED", "model hit its output limit"))
            result.attempts.append(Attempt(reply.text, violations))
            if not violations or attempt_no == self.max_repairs:
                break
            # Append-only repair turn: typed failure evidence -> new decision.
            messages.append({"role": "assistant", "content": reply.text})
            messages.append({"role": "user", "content": self._repair_prompt(
                violations, section, profile, project)})
        return result
