# grantwriter — evidence-bound grant application writer

Drafts grant applications for our products. The model writes the prose,
and deterministic checks decide whether the draft may be used.

Unlike a generic AI writer, every sentence must be traceable to a stored fact,
a plan item or the computed budget. A draft that invents numbers, overclaims
an unproven capability or breaks a call limit is rejected, not "polished".

## Pipeline

```
profile.yaml (facts + statuses) ─┐
call.yaml (eligibility, budget rules, sections, limits) ─┼─> eligibility gate ─> budget gate
project.yaml (plan items + budget lines) ─┘                    │ FAIL -> APPLICATION_BLOCKED
                                                               v
                        drafter (offline | model backend) per section
                                                               v
                        deterministic validator ──violations──> repair turn (bounded)
                                                               v
              application.md, application.annotated.md, report.json, manifest.json, SHA256SUMS
```

Status:

| Status | Meaning |
|---|---|
| `APPLICATION_BLOCKED` | eligibility or budget gate failed; nothing drafted |
| `APPLICATION_DRAFT_INVALID` | violations remain after the repair budget |
| `APPLICATION_DRAFT_VALID_WITH_OPEN_ITEMS` | text is valid; there are open items (unknown eligibility fields, synthetic call, placeholder plan) |
| `APPLICATION_DRAFT_VALID` | all gates passed |

A valid draft means the text passed deterministic checks. It is not a submitted
application, not a funding decision and not a replacement for a human reading
the official call text.

## Validator rules (`grantwriter/validate.py`)

Each sentence or list item must carry `[F:ID]`, `[P:ID]` or `[BUDGET]`.

| Code | Rule |
|---|---|
| `UNCITED_SENTENCE` | sentence without a marker |
| `UNKNOWN_FACT` / `UNKNOWN_PLAN_ITEM` | marker points to a missing id |
| `NUMBER_NOT_IN_SOURCE` | a number is not in the cited sources, or appears more often than in them |
| `STATUS_OVERCLAIM` | "validated / proven / fully / certified ..." next to a non-`PROVEN` fact without a qualifier ("not", "partially", "yet") |
| `FORBIDDEN_CLAIM` | a phrase from `profile.forbidden_claims` that is not negated |
| `OVER_WORD_LIMIT` / `OVER_CHAR_LIMIT` | call limit exceeded |
| `SECTION_EMPTY`, `TRUNCATED`, `MODEL_REFUSAL` | drafting failures |

Known limits: the checks are lexical. They do not detect a reworded claim that
inverts a fact's meaning without numbers or overclaim words, and the negation
handling is window-based. Human review of the annotated output stays required.

## Model backends

The validator and the repair loop are the same for every model, so a weak or
strong model changes the prose, never the checks.

| Backend | Use |
|---|---|
| `offline` | deterministic baseline, no model |
| `openai-compatible` | **in-house default: local model** (Ollama, llama.cpp server, LM Studio, vLLM). Product customers can point `--base-url` at any OpenAI-compatible cloud API and pass `--api-key-env NAME`; the key is read from that variable and never written to config or run records |
| `anthropic` | Claude via the official SDK (`pip install anthropic`), for customers who choose it |

## Usage

```bash
cd grant_writer
pip install -r requirements.txt

# 1. find opportunities on grant.market and screen them against the profile
python -m grantwriter discover --profile examples/profiles/1ua_age.yaml --out runs/discover
#    re-screen saved data after editing keywords, without fetching again:
python -m grantwriter discover --profile examples/profiles/1ua_age.yaml \
  --cached runs/discover/opportunities.json --out runs/discover

# 2. turn one opportunity into an UNVERIFIED call skeleton, then complete it
#    from the official call text and set verified: true
python -m grantwriter skeleton --opportunities runs/discover/opportunities.json \
  --id batch-5 --out calls/batch-5.yaml

# 3. eligibility and exclusion gates only (no drafting), e.g. for a real call
python -m grantwriter check --profile examples/profiles/parostok_kare.yaml --call examples/calls/upf4_2026.yaml

# 4. draft and validate
python -m grantwriter draft --profile P --call C --project J --out runs/app            # offline
ollama pull gemma4:e2b   # start the server with OLLAMA_CONTEXT_LENGTH=16384: the 4k default truncates repair turns
python -m grantwriter draft ... --backend openai-compatible --model gemma4:e2b         # local

python -m unittest discover -s tests
```

Exit code: 0 for a valid draft, 1 for blocked or invalid, 2 for an input error.

## Discovery (`grantwriter/sources.py`)

- grant.market: the RSS feed gives the list; each opportunity page gives schema.org
  `MonetaryGrant` JSON-LD (amount, currency, deadline, funder), the `opt-*`
  section blocks (audience, conditions, requirements) and external links, where
  the official call page usually is. Pages are fetched 1 s apart; a failing page
  is recorded as `_fetch_error` and the run continues.
- Screening is deterministic. Topic keywords are matched in the title and summary
  only, because full page text carries boilerplate. Requirement flags
  (consortium, NGO-only, individuals, women entrepreneurs, veterans) come from
  the full text, and there is a `min_score` threshold. Statuses are `CANDIDATE`,
  `EXCLUDED` and `EXPIRED`. Keyword screening is a coarse first filter; a
  candidate still needs a human or model reading of the official call.
- Usage policy: grant.market's robots.txt declares `ai-input=yes, ai-train=no`.
  Fetched content is used as input for screening and drafting only. It must not
  go into model training data, and it is not committed (`runs/` is git-ignored).
- More aggregators plug in as entries in `sources.SOURCES` plus a page parser.

## Inputs

- **Profile**: the applicant organization (registration data only; bank
  details and personal contacts are not stored here), a `search` block for
  screening, and facts with `status` from the evidence taxonomy (`PROVEN`,
  `PARTIALLY_PROVEN`, `NOT_PROVEN`, `CONFLICTING_UNRESOLVED`,
  `EXTERNAL_EVIDENCE_REQUIRED`, `PHYSICAL_VALIDATION_REQUIRED`), plus `source`
  and `as_of`. The organization fields stay `null` until filled from
  registration documents, so eligibility reports `UNKNOWN` instead of guessing.
- **Call**: a verified call needs `source_url` to the official text. A skeleton
  from an aggregator has `verified: false` and yields the open item
  `CALL_NOT_VERIFIED`. A passed `deadline` blocks the application. Conditions a rule
  engine cannot decide (e.g. "no pilot projects") go in `exclusions` and always surface
  as `EXCLUSION_CHECK_REQUIRED` open items, never as a silent pass. The bundled
  example call is **synthetic**.
- **Project**: plan items (future work) and budget lines. The bundled budget
  is a **placeholder**.

## Run records

Receipts of real runs live in `receipts/` (e.g. the first local-model runs and the
failure → change chain they produced).


`report.json` keeps every attempt with its violations and text hash, so each
failure → repair → result trace is stored. Those traces can later serve as
training and evaluation data.

## Attribution and scope

This is builder work (Claude Code, at the owner's request) in this repository.
It is not wired into JARVIS `agent/tools.py`; that repository is not available
here. Integrating it as a registered tool is a separate step.
