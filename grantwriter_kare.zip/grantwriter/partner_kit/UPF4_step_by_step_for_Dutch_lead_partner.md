---
title: "UPF4 grant: step-by-step guide for the Dutch lead partner"
subtitle: "Partnership with PE SPE KARE (Parostok), Odesa, Ukraine"
date: "Prepared 11 October 2026"
---

# Read this first (1 minute)

**What is UPF4?** UPF4 is the Ukraine Partnership Facility, a grant from the Dutch
Ministry of Foreign Affairs run by RVO. It pays **up to 90%** of a project that helps
Ukraine recover. The grant is between **€500,000 and €4,000,000**.

**Why do we need you?** Only a **company or organisation registered in the
Netherlands** can apply. You apply for the whole partnership. KARE (Ukraine) is your
partner. KARE cannot apply on its own.

**Is everything online?** Yes. There is no post and no paper. You fill in RVO's
online forms. KARE sends you texts and signed documents by e-mail, and you upload them.

**The two dates that matter:**

| Step | Opens | Closes |
|---|---|---|
| **Quick scan** (mandatory short check) | 23 Oct 2026, 10:00 | **3 Dec 2026, 17:00** |
| **Full application** | 4 Mar 2027, 10:00 | **8 Apr 2027, 17:00** |

You **cannot** send the full application without the quick scan. Miss the quick
scan and the project is out for this round.

---

# Step 1. Check that you can be the lead applicant (10 minutes)

Tick every box. If one box is empty, stop and tell KARE.

- [ ] Your organisation is registered in the Dutch Chamber of Commerce (KvK) and you know the KvK number.
- [ ] You have **at least 3 FTE** of salaried employees. (In a group or tax group, the whole group counts.) You will have to prove this.
- [ ] Your organisation has **at least 2 years of experience working in Ukraine** in the last 10 years. (Experience your staff gained at other organisations may count.)
- [ ] You can manage the project finances: payments, accounts and reports.
- [ ] Your organisation was founded **before 15 August 2024**.
- [ ] Your organisation (or group) has **no more than 2 UPF projects** that were awarded but are not yet finally closed.
- [ ] You can show **annual accounts for the last 2 years** (audited if you have them).
- [ ] You have, or will write, an **integrity policy** (on sexual misconduct and abuse of power) and you follow the **OECD guidelines** for responsible business.

# Step 2. Get eHerkenning now (start today, it takes time)

eHerkenning is the Dutch business login. RVO requires **level 2+ or higher**.

1. Go to <https://www.eherkenning.nl> and pick a recognised eHerkenning supplier.
2. Order eHerkenning **level 2+ (EH2+) or level 3**.
3. Make sure that the person who will submit the application is **authorised for RVO services**.
4. Wait for activation. This can take days or weeks, so do not leave it until March.

You **must** have it for the full application. The quick scan form may also ask you to
log in, so try to have it ready by 23 October.

# Step 3. Read the rules (30 minutes)

- RVO page: <https://english.rvo.nl/subsidies-financing/upf>
- How to apply: <https://english.rvo.nl/en/topics/upf/apply-upf>
- Full rules (English, unofficial translation): <https://english.rvo.nl/sites/default/files/2026-10/Unofficial-translation-of-the-UPF-Government-Gazette-publication-October-2026.pdf>
- Questions and answers: <https://english.rvo.nl/en/subsidies-financing/upf-qa>
- RVO e-mail for questions: **upf@rvo.nl**

**The 4 traps that get projects rejected.** Read them twice.

1. **No pilots, no experiments, no feasibility studies.** The project must deliver a real, finished result.
2. **No "experimental technology".** RVO wants proof that the solution already works.
3. **Not "commercially fundable".** If a bank or investor would pay for it anyway, it is out. No profit mark-ups in the budget.
4. **Not for one company only.** The benefit must go to a community or a chain of farms, not just to KARE or to you.

# Step 4. Agree the project with KARE (1 to 3 calls)

KARE has sent you a **concept note** (a separate file). It is a **draft**. Decide together:

- [ ] The project title.
- [ ] Your role and KARE's role. RVO checks that **every partner is necessary**.
- [ ] Which farmer cooperatives or communities will benefit, and in which regions.
- [ ] How many service points, how long (6 months to 4 years), and the rough budget.
- [ ] Who pays the **own contribution of at least 10%**. Money from the Dutch Ministry of Foreign Affairs does not count.
- [ ] Whether you want to invite more partners (maximum 6 partners in total).

Write the answers down in an e-mail and send it to KARE.

# Step 5. Fill in the quick scan (between 23 Oct and 3 Dec 2026)

1. Open: <https://english.rvo.nl/en/topics/upf/apply-upf>
2. Click **"Complete the quick scan"**.
3. Copy the texts from the concept note into the form and adjust them to what you agreed in Step 4.
4. If you cannot finish in one go, click **"Save form"**. Choose a password (8 characters or more) and **write down the ID** the form shows. You need both to continue later.
5. Attach any documents the form asks for.
6. Submit, and **save the confirmation**.
7. RVO sends **non-binding advice within 4 weeks**. Forward it to KARE.
8. **Keep the reference number** from RVO's advice. The full application needs it.

# Step 6. Prepare the full application (December 2026 to March 2027)

All documents must be **in English**. KARE helps with every text.

| # | Document | Who makes it | Who signs |
|---|---|---|---|
| 1 | Quick scan **reference number** (from RVO's advice) | RVO | — |
| 2 | **Annex I – Project proposal** (activities, results, local needs, risks, how partners work together) | KARE drafts, you finalise | — |
| 3 | **Annex II – Budget Excel**, with the own contribution per partner and a **liquidity forecast per partner per quarter** | Together | — |
| 4 | **Annex III – Cooperation agreement** (roles and obligations) | Together | **All partners** |
| 5 | **Partner form** for each partner | Each partner | Each partner |
| 6 | Your **annual accounts** for the 2 years before 2027 (2026 and 2025); audited if available, otherwise RVO's Q&A lists what to send instead | You | — |
| 7 | Annual accounts of any partner contributing **€25,000 or more** of its own money | That partner | — |
| 8 | Proof of **at least 3 FTE** employees | You | — |
| 9 | **RBC self-assessment** (responsible business conduct, OECD) | You | — |
| 10 | Your **KvK number** and **bank details** | You | — |
| 11 | If someone else submits for you: **Annex V – Authorisation intermediary form** | You | You |

RVO publishes the official UPF4 templates on the "Apply for UPF" page. Always use those.

# Step 7. Submit the application (4 Mar to 8 Apr 2027)

1. Log in to RVO with **eHerkenning** (Step 2).
2. Fill in the online application form.
3. Upload **all** documents from Step 6.
4. Submit **as early as possible**. RVO assesses complete applications **first come, first served**, and the budget (€26.5 million) can run out.
5. Save the confirmation and send a copy to KARE.

# Step 8. After you submit

- RVO decides **within about 13 weeks**.
- To get the grant, an application needs **at least 65 points**, with minimum scores per criterion.
- If approved, the project must **start within 2 months**.

---

# Contacts

- **KARE / Parostok:** mwparostok@gmail.com, <https://www.parostokmw.com>
- **RVO:** upf@rvo.nl

*This guide summarises RVO's public information as checked on 11 October 2026. Only
the Dutch Government Gazette text is legally binding. If anything here differs from
RVO's website, RVO's website wins.*
