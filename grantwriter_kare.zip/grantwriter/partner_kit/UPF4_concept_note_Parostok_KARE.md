---
title: "Concept note for UPF4 quick scan"
subtitle: "Shared seed-treatment service for farms in southern Ukraine"
date: "Draft, 11 October 2026"
---

**Programme:** Ukraine Partnership Facility 4 (RVO), sector agriculture and agrifood
**Lead applicant:** [Dutch partner: name, KvK number]
**Ukrainian partner:** PE SPE "KARE" (Parostok), Odesa, EDRPOU 37351868, founded 2010
**Other partners:** farmer cooperatives in southern Ukraine [names to be confirmed]
**Duration:** [6 months to 4 years, to be agreed]  **Grant requested:** [€500,000 to €4,000,000, to be agreed]

# 1. Baseline situation and local needs

Farms in southern Ukraine sow under war conditions. Much of their seed is their own,
often of uncertain quality, and the access to inputs and services is limited. Small and
medium farms, especially in front-line and de-occupied communities, need affordable ways
to make the most of the seed they already have and to cut losses in storage.

Parostok is a chemical-free seed treatment that uses controlled microwave irradiation
before sowing and before storage. KARE, an Odesa engineering company founded in 2010,
designs and manufactures the Parostok units.

# 2. Activities and intended results

The partnership will set up a shared seed-treatment service:

- **Service points.** Install Parostok units at existing seed-cleaning points of farmer
  cooperatives in southern Ukraine and run them as a shared service for small and medium farms.
- **Pre-sowing treatment.** Treat farmers' own seed before sowing, with priority for farms
  in front-line and de-occupied communities and for farms led by women, young people and war veterans.
- **Storage protection.** Treat stored grain at the same points to reduce losses from storage pests.
- **Local operators.** Train operators employed by the cooperatives to run and maintain the units.
- **Measured results.** Measure the results on served farms with replicated untreated control
  strips and independent laboratory germination tests, and share them with the farming community.

**Intended results:** [number of service points], [number of farms served],
[tonnes of seed treated per season], [number of operators trained]. Targets are set with the lead partner.

# 3. Benefit for local communities

The service is shared, so the benefit goes to many farms rather than to one company.
Priority goes to farms in front-line and de-occupied communities and to farms led by women,
young people and war veterans. Operators are hired locally by the cooperatives, and the jobs
remain after the project. Once the units are installed and the operators are trained, the
cooperatives can keep the service running for their members.

# 4. Partnership and roles

- **[Dutch lead partner]:** manages the project, its finances and reporting, and brings
  seed-chain and agronomic expertise. [Exact role to be agreed.]
- **KARE (Ukraine):** manufactures, installs and services the units and trains the operators.
- **Farmer cooperatives:** host the service points and organise access for their members.

Each partner is needed: without the lead partner there is no project management or Dutch
expertise; without KARE there is no technology or service; without the cooperatives there
is no access to farms.

# 5. Evidence available today

- **Safety (independent).** In April 2026, the Plant Health Institute of Ukravit Science Park,
  an independent laboratory, tested 36 corn seed samples from 6 lots at 5 treatment modes and
  untreated controls (DSTU 4138-2002). It reported uniform root development without signs of
  suppression. *(Protocol No. 03990-04025-26-S. Permission from the Institute is needed before
  attaching it.)*
- **Weaker seed responds more.** In the same test, the weakest lot (86% germination untreated)
  gained 6.2 percentage points on average, while lots at 90 to 92% changed by −1.6 to +1.6 points.
- **Field result.** In a 2024 corn trial at RSUW Głuchów (Poland), KWS Nataelo from treated seed
  gave 11.97 t/ha of dry grain against 10.34 t/ha untreated (+15.7%). This was a single plot per
  variant without replication.
- **Earlier research.** A research programme around 2000–2001 with the Odessa State Agricultural
  Experimental Station ran replicated field experiments on winter wheat.

# 6. Main risks and mitigation

- **War.** Start in communities away from active hostilities, keep spare units in Odesa, and
  move equipment if the security situation changes.
- **Strength of evidence.** Independent data so far show that the treatment is safe and helps
  weaker seed most. Yield gains still need replicated field data. The project measures results
  on every served farm with control strips and independent laboratory tests.
- **Due diligence.** All partners, suppliers and beneficiaries will be screened for sanctions
  and reputational risks, including any activities in Russia.

---

*Items in [brackets] must be agreed with the Dutch lead partner before the quick scan
(23 October – 3 December 2026).*
